# Install hook code here
puts "The list of countries provided by this plugin may offend some users. Please review it carefully before you use it"