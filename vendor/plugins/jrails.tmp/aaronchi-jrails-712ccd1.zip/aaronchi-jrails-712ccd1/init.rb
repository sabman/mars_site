require 'rails/init.rb'
